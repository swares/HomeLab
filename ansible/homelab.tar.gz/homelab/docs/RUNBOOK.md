# Runbook

Operational procedures for the H4 core. Commands assume you're the `ansible` user with the
kubeconfig at `~/.kube/config` and run playbooks from `ansible/`.

## Initial install

### 1. Partition map (done at OS install, by hand)

Ansible deliberately does **not** repartition the live root disk. Lay this out when you
install the host OS on the NVMe:

| Partition | Size | Mount | Notes |
|-----------|------|-------|-------|
Put the **OS on the 256 GB eMMC** so the entire NVMe serves the cluster + NAS:

| Device | Partition | Size | Mount | Notes |
|--------|-----------|------|-------|-------|
| eMMC | `mmcblk0p1/2/3` | 256 GB | `/boot/efi`, `/boot`, `/` | Host OS + `/var/lib/microshift` (etcd) |
| NVMe | `nvme0n1p1` | ~1.5 TB | `lv_nas` | live NAS data |
| NVMe | `nvme0n1p4` | rest (~2.5 TB) | — | **Left free** for the LVMS VG (`microshift_pv_device`) |

The two cold mirrors (8 TB `md0`, 6 TB `md1`) are mounted in the next step.

### 2. Cold tiers (two mdadm RAID 1 mirrors)

Both cold tiers are mdadm RAID 1 mirrors (pre-created — the playbook never runs `mdadm --create`).
`storage.yml` mounts the **8 TB mirror** (`md0`) at `/mnt/cold-8t` and the **6 TB mirror** (`md1`)
at `/mnt/cold-6t` (XFS, formatted only if empty), installs **smartd + mdadm monitoring** so a
climbing CRC count or a dropped member alerts you, and the backup timers keep a primary restic
repo on `md0` and a `restic copy` on `md1`. Each mirror survives one disk failure in place.
Nothing destructive runs against a populated array. See
[Cold tier options](#cold-tier-options) for alternatives.

### 3. DNS records

On your chosen DNS host, add these records (wildcard via dnsmasq):

| Record | Type | Value |
|--------|------|-------|
| `api.lab.home.arpa` | A | `10.136.151.64` |
| `*.apps.lab.home.arpa` | A | `10.136.151.64` |

The updated map leaves **DNS unassigned** (the old Pi-hole Zero now runs Grafana). Pick a
stable always-on host — a Zero 2 W, an Orange Pi 5 Pro, or `dnsmasq` on the H4 — and add the
records there (dnsmasq wildcard: `address=/apps.lab.home.arpa/10.136.151.64`). Missing or
wrong DNS is the most common reason MicroShift "installs but nothing works."

### 4. Secrets

- `ansible/files/pull-secret.json` — free pull secret from
  <https://console.redhat.com/openshift/install/pull-secret>
- `/etc/restic/password` on the host (mode 0700) — restic repo password
- `ansible/.vault_pass` — Ansible Vault password (gitignored)

### 5. Run the stages

```bash
make check        # dry run
make storage
make microshift
make backup
make argocd
```

## Verify a healthy cluster

```bash
oc get nodes                      # node Ready
oc get pods -A                    # control plane + router + lvms running
oc get sc                         # confirm the LVMS StorageClass name
oc get route -A                   # Routes resolve to *.apps.lab.home.arpa
systemctl status backup-nas.timer backup-etcd.timer
```

## Deploy a workload

1. Copy `gitops/workloads/sample-app/` to `gitops/workloads/<name>/` and edit the
   manifests (image, host, PVC size).
2. Add `gitops/apps/<name>.yaml` (copy `sample-app.yaml`, change `name`/`path`/`namespace`).
3. Open a PR; on merge, Argo deploys it. Watch with `argocd app get <name>` or the UI.

Never `oc apply` a workload directly — it'll drift and Argo will fight you. Change git.

## Backups

| Stream | When | What | Downtime |
|--------|------|------|----------|
| `backup-nas` | daily 01:30 | restic of `/srv/nas` → 8 TB, then `restic copy` → 6 TB | none |
| `backup-etcd` | Sun 03:00 | `microshift backup` → 8 TB | brief (service stop/start) |

Check: `restic snapshots` (set `RESTIC_REPOSITORY`/`RESTIC_PASSWORD_FILE`), and
`ls /mnt/raid/microshift-backups`. Retention is handled inside the timer — **do not** run
`restic forget`/`prune` by hand (it's denied in the permission config for this reason).

## Recovery scenarios

**UDMA CRC errors (SMART 199) — triage BEFORE replacing a disk.** `UDMA_CRC_Error_Count` is a
**link-layer** fault (cable / connector / SATA power / controller), not the platters. Two disks
erroring identically => a shared cause, not two bad drives. Don't RMA first.

```bash
smartctl -a /dev/sdX | grep -E "UDMA_CRC|Reallocated_Sector|Current_Pending|Offline_Uncorrectable"
# 199 climbing  => active link problem.  5/197/198 all 0 => media is FINE (link-only).
```
Fix order: (1) reseat/replace SATA **data** cables (latching; don't bundle — crosstalk);
(2) check SATA **power** (the H4 powers drives off-board — a marginal/overloaded splitter is a
classic cause with two spinning 8 TB drives); (3) move disks to **different SATA ports**;
(4) update the **H4 BIOS**; (5) re-test under a full array read and watch 199. If 199 stops
climbing after a cable+power+port swap, the disks were never the problem. If it climbs only on
the H4 across cables/ports, suspect the board's SATA controller (documented H4 failure mode).

**RAID 1 member dropped (often CRC-induced link resets).** The array is degraded, not lost — the
platter data is intact. After fixing the link:
```bash
cat /proc/mdstat                      # see which member fell out
mdadm --detail /dev/md0               # confirm state
mdadm /dev/md0 --re-add /dev/sdX1     # re-add; it resyncs (watch /proc/mdstat)
```
Only if SMART 5/197/198 are non-zero (real media damage) do you replace the disk:
`mdadm --manage /dev/md0 --fail /dev/sdX1 --remove /dev/sdX1`, fit the new disk, partition to
match, `--add`, let it rebuild.

**Lost a disk in a cold mirror.** The mirror stays online degraded — no data loss, no restore.
Fix per the mdadm re-add/rebuild steps above. (The old "independent disks + restic copy" recovery
below applies only if you ever run the tiers un-mirrored.) Replace the failed
disk, recreate the XFS filesystem on it (`make storage`), then re-seed it from the survivor:
```bash
restic -r /mnt/cold-8t/restic copy --repo2 /mnt/cold-6t/restic   # (or reverse, toward the new disk)
```

**Lost the NVMe (whole hot tier).** This is recoverable because state + config are
off-tier:
1. Replace the drive, reinstall the host OS with the partition map above.
2. `make storage` (the cold disks still have your data).
3. Restore MicroShift state from the latest `/mnt/raid/microshift-backups/<ts>` with
   `microshift restore`, then `make microshift`.
4. Restore NAS data from the 8 TB: `restic -r /mnt/cold-8t/restic restore latest --target /srv/nas`.
5. `make argocd` — Argo rebuilds all workloads from git.

**Lost the whole box.** You need the offsite copy (see below). Without it, cluster config
survives in git but NAS *data* does not.

## Cold tier options

The 8 TB + 6 TB pair is mismatched, so pick the model that fits how you use cold storage:

1. **Two independent disks + `restic copy` (this repo's default).** 8 TB is the primary repo;
   the 6 TB holds a copy. Full capacity used, two-disk redundancy for backup data, no RAID
   matched-size constraint. Best for a backup/snapshot tier.
2. **SnapRAID (+ mergerfs).** Use the 8 TB as parity for the 6 TB of data. Single-disk fault
   tolerance with mismatched sizes; parity is point-in-time (synced on a schedule), which is
   fine for cold/archive/media that changes slowly. Reach for this if you add bulk data disks.
3. **Partition-and-mirror.** Split the 8 TB into 6 TB + 2 TB and `mdadm` RAID 1 the two 6 TB
   regions for real-time redundancy, leaving 2 TB as scratch. Wastes the 2 TB and the size
   flexibility; only worth it if you specifically want a live mirror on the cold tier.

## Roadmap: offsite (3-2-1)

Two on-box copies protect against a disk failure, not a box/room failure. The next durability step is
one copy off the box — restic can replicate the same (already-encrypted) repo to a second
machine or to S3/Backblaze B2. Add a `backup-offsite.timer` mirroring the restic repo when
you're ready.
